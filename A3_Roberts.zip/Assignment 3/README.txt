In order to run the assignment, please click on Assignment3.py, and click run. You will then be prompted to select an image. Once you select the image,
The GUI will pop up where you are able to apply thresholding methods. You can then click the reset image button
in the top right to reset the iage and apply another thresholding method. You are also able to input a manual threshold,
and an offset value for the mean C method.

The libraries that were used are:
    PyQT/sys: File exploer for loading image
    MatPlotLib: Only for GUI, no built in functions were used apart from creating GUI
    Numpy: Padding, array conversions/operations, NO HISTOGRAM FUNCTIONS WERE USED, I BUILT MY OWN HISTOGRAM FUNCTION
    PIL: Loading images

Added Feature: Reset Image button

NOTE: I am aware of the Auto thresholding not displaying the thresholding lines after applying. I'm not sure
what the issue is, but I wasnt able to resolve it in time.