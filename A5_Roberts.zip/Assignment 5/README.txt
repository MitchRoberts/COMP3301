Mitch Roberts, 202128955

In order to run the assignment, please click on Assignment5.py, and click run. You will then be prompted in terminal with the option "webcam" or "image", where you can then
type out the option you want, either webcam or image, then you will the be prompted to either detect your face, or detect corners on either a pre loaded image or your webcam. 
If you type in something else that isn't any of the options, it will defualt to use webcam, and face.

The libraries that were used are:
    PyQT/sys: File exploer for loading image
    Numpy: Arrays, Types
    PIL: Loading images

NOTE: I amaware that the face feature detection isn't perfect, it seems to work well for everything but the eyes. I assume this is because the functions are just not perfect, but have
no time to trouble shoot to verify this